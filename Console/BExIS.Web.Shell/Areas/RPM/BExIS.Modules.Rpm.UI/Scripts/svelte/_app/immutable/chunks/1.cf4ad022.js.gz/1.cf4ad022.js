import{default as t}from"../entry/error.svelte.478968c6.js";export{t as component};
