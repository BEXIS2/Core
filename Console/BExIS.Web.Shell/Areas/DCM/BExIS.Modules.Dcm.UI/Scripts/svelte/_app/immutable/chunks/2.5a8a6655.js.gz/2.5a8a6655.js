import{_ as r}from"./_layout.1f16b6c2.js";import{default as t}from"../entry/test-layout.svelte.2c1ae85c.js";export{t as component,r as universal};
