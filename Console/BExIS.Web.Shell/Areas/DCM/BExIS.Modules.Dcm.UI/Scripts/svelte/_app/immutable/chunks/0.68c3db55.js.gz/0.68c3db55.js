import{_ as r}from"./_layout.c51e0381.js";import{default as t}from"../entry/layout.svelte.a0b37512.js";export{t as component,r as universal};
