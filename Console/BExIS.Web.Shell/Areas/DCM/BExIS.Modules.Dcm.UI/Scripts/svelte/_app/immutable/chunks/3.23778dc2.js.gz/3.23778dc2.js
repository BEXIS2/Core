import{default as t}from"../entry/_page.svelte.da17dedb.js";export{t as component};
