import{default as t}from"../entry/error.svelte.3b974f51.js";export{t as component};
