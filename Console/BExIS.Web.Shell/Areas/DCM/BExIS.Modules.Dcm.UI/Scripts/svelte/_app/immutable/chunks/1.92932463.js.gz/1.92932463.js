import{default as t}from"../entry/error.svelte.ad616449.js";export{t as component};
