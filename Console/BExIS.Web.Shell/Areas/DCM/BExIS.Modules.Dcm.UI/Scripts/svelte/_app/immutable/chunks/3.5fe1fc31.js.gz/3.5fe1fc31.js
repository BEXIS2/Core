import{default as t}from"../entry/test-page.svelte.aeabd045.js";export{t as component};
