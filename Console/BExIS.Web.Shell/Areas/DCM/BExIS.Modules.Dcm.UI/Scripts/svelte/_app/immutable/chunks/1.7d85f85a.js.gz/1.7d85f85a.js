import{default as t}from"../entry/error.svelte.ed945e95.js";export{t as component};
